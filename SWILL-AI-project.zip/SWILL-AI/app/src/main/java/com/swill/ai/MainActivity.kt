package com.swill.ai

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 14, 12)
    private val panel = Color.rgb(20, 29, 24)
    private val green = Color.rgb(0, 230, 118)
    private lateinit var log: LinearLayout
    private lateinit var input: EditText
    private lateinit var keyInput: EditText
    private var apiKey = ""
    private var selectedFileText = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        addMessage("SWILL AI", "Основа приложения готова. Добавь Gemini API-ключ в настройках, чтобы включить онлайн-чат.")
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 18, 16, 12)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "SWILL AI  /  AUTOPILOT"
            textSize = 22f
            setTextColor(green)
            gravity = Gravity.CENTER_VERTICAL
        }
        outer.addView(title, LinearLayout.LayoutParams(-1, 52))
        val subtitle = TextView(this).apply {
            text = "AI-разработчик • ранняя версия 0.1.0"
            textSize = 12f
            setTextColor(Color.LTGRAY)
        }
        outer.addView(subtitle)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val settings = button("НАСТРОЙКИ") { showSettings() }
        val file = button("ОТКРЫТЬ ФАЙЛ") { pickFile() }
        actions.addView(settings, LinearLayout.LayoutParams(0, 48, 1f))
        actions.addView(file, LinearLayout.LayoutParams(0, 48, 1f))
        outer.addView(actions)
        val scroll = ScrollView(this)
        log = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 10, 10, 10)
        }
        scroll.addView(log)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        input = EditText(this).apply {
            hint = "Опиши задачу для SWILL AI..."
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 15f
            setBackgroundColor(panel)
            setPadding(12, 8, 12, 8)
        }
        outer.addView(input, LinearLayout.LayoutParams(-1, 54))
        val send = button("ОТПРАВИТЬ ЗАДАНИЕ") { sendPrompt() }
        outer.addView(send, LinearLayout.LayoutParams(-1, 50))
        setContentView(outer)
    }

    private fun button(label: String, click: () -> Unit) = Button(this).apply {
        text = label
        textSize = 11f
        setTextColor(green)
        setBackgroundColor(panel)
        setOnClickListener { click() }
    }

    private fun addMessage(who: String, body: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 10)
            setBackgroundColor(panel)
        }
        val head = TextView(this).apply {
            text = who
            textSize = 12f
            setTextColor(green)
        }
        val text = TextView(this).apply {
            this.text = body
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, 5, 0, 0)
        }
        box.addView(head)
        box.addView(text)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 6, 0, 6)
        log.addView(box, lp)
    }

    private fun showSettings() {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 16, 24, 8)
            setBackgroundColor(bg)
        }
        wrap.addView(TextView(this).apply {
            text = "Подключение Gemini"
            textSize = 19f
            setTextColor(green)
        })
        keyInput = EditText(this).apply {
            hint = "Вставь Gemini API-ключ"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            inputType = 129
            setSingleLine(true)
        }
        wrap.addView(keyInput)
        wrap.addView(TextView(this).apply {
            text = "Ключ хранится только в памяти приложения до его закрытия. Не публикуй его в GitHub и не отправляй другим людям."
            textSize = 12f
            setTextColor(Color.LTGRAY)
        })
        AlertDialogBuilder.show(this, wrap) {
            apiKey = keyInput.text.toString().trim()
            addMessage("СИСТЕМА", if (apiKey.isBlank()) "API-ключ не задан." else "Ключ принят в оперативную память. Можно отправлять запросы Gemini.")
        }
    }

    private fun sendPrompt() {
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        input.setText("")
        addMessage("ТЫ", prompt)
        if (apiKey.isBlank()) {
            addMessage("SWILL AI", "Сначала открой НАСТРОЙКИ и добавь Gemini API-ключ.")
            return
        }
        addMessage("SWILL AI", "Запрос отправлен. Ожидаю ответ модели…")
        thread {
            val answer = try { callGemini(prompt) } catch (e: Exception) {
                "Ошибка запроса: ${e.message ?: "неизвестная ошибка"}"
            }
            runOnUiThread { addMessage("GEMINI", answer) }
        }
    }

    private fun callGemini(prompt: String): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$apiKey")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        val body = JSONObject().put("contents", JSONArray().put(
            JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))
        )).toString()
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        if (conn.responseCode !in 200..299) return "Gemini вернул HTTP ${conn.responseCode}: $response"
        val json = JSONObject(response)
        return json.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
            ?.optString("text") ?: "Модель вернула пустой ответ."
    }

    private fun pickFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, 42)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri)?.bufferedReader()?.use {
                    selectedFileText = it.readText()
                }
                addMessage("ФАЙЛ", "Файл открыт для просмотра. Первые 4000 символов:\n" +
                    selectedFileText.take(4000))
            } catch (e: Exception) {
                addMessage("ФАЙЛ", "Не удалось прочитать файл: ${e.message}")
            }
        }
    }
}

private object AlertDialogBuilder {
    fun show(activity: Activity, view: View, onSave: () -> Unit) {
        android.app.AlertDialog.Builder(activity)
            .setView(view)
            .setPositiveButton("СОХРАНИТЬ") { _, _ -> onSave() }
            .setNegativeButton("ОТМЕНА", null)
            .show()
    }
}
